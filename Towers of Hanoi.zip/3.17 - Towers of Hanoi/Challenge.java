import java.util.Scanner;
class Challenge
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int[] array = {0,0,0,0,0};
        int[] array2 = {0,0,0,0,0};
        int[] array3 = {0,0,0,0,0};
        int i = 0;
        int a = 0;
        int b = 0;
        int  towers = 0;
        int disk = 0;
        String option = "";
        int length = array.length;
        int length2 = array2.length;
        int length3 = array3.length;
        
        while(!option.equals("e"))
        {
            for (int h = 0; h<length ; h++)
            {
                System.out.print(array[h]);
            }
            System.out.println();
            for ( int h = 0; h<length2 ; h++)
            {
                System.out.print(array2[h]);
            }
            System.out.println();
            for ( int h = 0; h<length3 ; h++)
            {
                System.out.print(array3[h]);
            }
            System.out.println();
            System.out.println("pick one of the following option ([p]ut,[r]emove,[e]xit");
            option = input.nextLine();
            if (option.equals("p"))
            {
                System.out.println("Which disk size");
                disk = Integer.parseInt(input.nextLine());
                System.out.println("Which tower");
                towers = Integer.parseInt(input.nextLine());

                if(towers == 1)
                {
                    if(disk >=1 && disk <=4)
                    {
                        if(i <= 3 )
                        {
                            array[i] = disk;
                            i++;
                        }
                    }
                }
                else if(towers == 2)
                {
                    if(disk >=1 && disk <=4)
                    {
                        if(a <= 3 )
                        {
                            array2[a] = disk;
                            a++;
                        }
                    }
                }
                else if(towers == 3)
                {
                    if(disk >=1 && disk <=4)
                    {
                        if(b <= 3 )
                        {
                            array3[b] = disk;
                            b++;
                        }
                    }
                }
            }
            else if(option.equals("r"))
            {
                System.out.println("Which tower");
                towers = Integer.parseInt(input.nextLine());

                if(towers == 1)
                {
                    if(i >= 0)
                    {
                        i--;
                        array[i] = 0;
                    }
                }
                else if(towers == 2)
                    {
                        if(a >= 0)
                        {
                            a--;
                            array2[a] = 0;
                        }
                    }
                else  if(towers == 3)
                        {
                            if(b >= 0)
                            {
                                b--;
                                array3[b] = 0;
                            }
                        }
                    }
                }
            }
        }
    

