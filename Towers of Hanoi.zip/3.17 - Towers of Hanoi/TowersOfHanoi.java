import java.util.Scanner;
class TowersOfHanoi
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        int[] array = {0,0,0,0,0};
        int i = 0;
        int disk = 0;
        String option = "";
        int length = array.length;
        while(!option.equals("e"))
        {

            for (int h = 0; h<length ; h++)
            {
                System.out.print(array[h]);
            }
            System.out.println();
            System.out.println("pick one of the following option ([p]ut,[r]emove,[e]xit");
            option = input.nextLine();
            if (option.equals("p"))
            {
                System.out.println("Which disk size");
                disk = Integer.parseInt(input.nextLine());

                if(disk >=1 && disk <=4)
                {
                    if(i <= 3 )
                    {
                        array[i] = disk;
                        i++;

                    }
                }
            }
               else if(option.equals("r"))
                {
                    if(i >= 0)
                    {
                        i--;

                        array[i] = 0;
                        
                    }
                }
            }
        }
    }


