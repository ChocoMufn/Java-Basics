import java.util.Scanner;
public class Receipt {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter your subtotal $:");
    double total = input.nextDouble(); 
    
    double taxTotal = total * 1.15;
    
    System.out.println("Your total including tax comes to $:");
    System.out.println(taxTotal);
  }
}