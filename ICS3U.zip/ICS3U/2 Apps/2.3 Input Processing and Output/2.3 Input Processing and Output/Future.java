import java.util.Scanner;
public class Future {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("What year is it?:");
    int year = input.nextInt(); 
    
    int future = year + 1;
    
    System.out.println("In one year, it will be ");
    System.out.println(future);
  }
}