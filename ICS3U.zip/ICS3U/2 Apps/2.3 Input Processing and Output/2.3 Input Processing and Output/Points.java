
import java.util.Scanner;
public class Points {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter the number of free-throws (1 pt.each):");
    int freeThrows = input.nextInt(); 
    
    int ft = freeThrows;
    
    System.out.println("Enter the number of free-throws (2 pt.each):");
    int fieldGoals = input.nextInt(); 
    
    int fg = fieldGoals * 2;
    
    System.out.println("Enter the number of free-throws (3 pt.each):");
    int threePointers = input.nextInt(); 
    
    int tp = threePointers * 3;
    
    int points = ft + fg + tp;
    
    System.out.println("Total points:");
    System.out.println(points);
  }
}