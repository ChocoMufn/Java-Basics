import java.util.Scanner; 
public class Grade
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("What grade are you in?");
    int grade = input.nextInt();
    
    if (grade >=9 && grade <=12)
    {
        System.out.println("You are in highschool.");
    }
    else
    {
        System.out.println("You are not in highschool.");
    }
    
    
}
}