import java.util.Scanner; 
public class PaintMixer
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println(" ");
    System.out.println("Welcome to color mixer!");
    System.out.println(" ");
    System.out.println("These are the colors that can be chosen");
    System.out.println(" ");
    System.out.println("- Green");
    System.out.println("- Blue");
    System.out.println("- Red");
    System.out.println(" ");
    
    
    System.out.println("What is color 1");
    String color1 = input.nextLine();
    
    System.out.println("What is color 2");
    String color2 = input.nextLine();
   
    
    if ((color1.toLowerCase().equals("green") && color2.toLowerCase().equals("blue")) || (color1.toLowerCase().equals("blue") && color2.toLowerCase().equals("green")))
    {
        System.out.println("Your colour is Teal!");
    }
    else if ((color1.toLowerCase().equals("blue") && color2.toLowerCase().equals("red")) || (color1.toLowerCase().equals("red") && color2.toLowerCase().equals("blue")))
    {
        System.out.println("Your colour is Purple!");
    }
    else if ((color1.toLowerCase().equals("green") && color2.toLowerCase().equals("red")) || (color1.toLowerCase().equals("red") && color2.toLowerCase().equals("green")))
    {
        System.out.println("Your colour is Brown!");
    }
    else
    {
        System.out.println("INVALID INPUT RECIEVED! TERMINATE PROGRAM AND RETRY!");
    }
    
    
}
}