import java.util.Scanner; 
public class Skiing
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("Do you have your skiis");
    String skiis = input.nextLine();
    
    System.out.println("Do you  have your boots?");
    String boots = input.nextLine();
   
    
    if (skiis.toLowerCase().equals("yes") && boots.toLowerCase().equals("yes"))
    {
        System.out.println("You are ready to go skiing!");
    }
    else
    {
        System.out.println("You are missing something.");
    }
    
    
}
}