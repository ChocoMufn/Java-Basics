import java.util.Scanner; 
public class HomeworkTheGame
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("Welcome to School Life: Homework! What's your name?");
    String name = input.nextLine();
    
    System.out.println(" ");
    System.out.println("Teacher: " + name +"! Did you do your homework?!");
    System.out.println(" ");
    System.out.println("It was at this moment, that " + name + " knew it may be the end");
    System.out.println(" ");
    
    
    
    System.out.println("Techer: Did you do your homework? (yes/no)");
    String did = input.nextLine();
    
    
   
    
    if (did.toLowerCase().equals("yes"))
    {
        System.out.println("Teacher: Ok");
    }
    else if (did.toLowerCase().equals("no"))
    {
        System.out.println("Teacher: Did you atleast attempt it? (yes/no)");
        String attempt = input.nextLine();
        if (attempt.toLowerCase().equals("yes"))
        {
            System.out.println("Teacher: well, atleast you tried");
        }
        else if(attempt.toLowerCase().equals("no"))
        {
            System.out.println("Teacher: Not Ok");
            System.out.println(" ");
            System.out.println("GAME OVER!");
        }
        else
        {
            System.out.println("INVALID INPUT RECIEVED! TERMINATE PROGRAM AND RETRY!");
        }
    }
    
    else
    {
        System.out.println("INVALID INPUT RECIEVED! TERMINATE PROGRAM AND RETRY!");
    }
}
}