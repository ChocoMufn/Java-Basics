
import java.util.Scanner; 
public class Driving
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("What is the color of the stoplight?");
    String color = input.nextLine();
    
    System.out.println("What is your speed?");
    int speed = input.nextInt();
   
    
    if (color.toLowerCase().equals("green") || (color.toLowerCase().equals("yellow") && speed >= 60))
    {
        System.out.println("Go!");
    }
    else
    {
        System.out.println("Stop!");
    }
    
    
}
}