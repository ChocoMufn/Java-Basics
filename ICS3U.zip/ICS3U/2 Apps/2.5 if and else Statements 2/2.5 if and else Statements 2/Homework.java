import java.util.Scanner; 
public class Homework
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    
    
    
    System.out.println("Techer: Did you do your homework? (yes/no)");
    String did = input.nextLine();
    System.out.println("Teacher: Did you atleast attempt it? (yes/no)");
    String attempt = input.nextLine();
    
   
    
    if (did.toLowerCase().equals("yes"))
    {
        System.out.println("Teacher: Ok");
    }
    else if (did.toLowerCase().equals("no") && did.toLowerCase().equals("no"))
    {
        System.out.println("Teacher: Not Ok");  
    }
    
    else if (did.toLowerCase().equals("no") && attempt.toLowerCase().equals("no"))
    {
        System.out.println("Teacher: Ok");
    }
    
    else
    {
        System.out.println("INVALID INPUT RECIEVED! TERMINATE PROGRAM AND RETRY!");
    }
}
}