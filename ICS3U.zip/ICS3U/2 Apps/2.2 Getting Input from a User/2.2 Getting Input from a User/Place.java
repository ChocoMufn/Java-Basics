import java.util.Scanner;
public class Place {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("What is your city?");
    String city = input.nextLine();
    
    System.out.println("What is your province?");
    String province = input.nextLine();
    
    System.out.println(city + ", " + province);
  }
}
