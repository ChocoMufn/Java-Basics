import java.util.Scanner;
public class Sundae {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter an ice cream flavour:");
    String flavour = input.nextLine();
    
    System.out.println("Enter a fruit:");
    String fruit = input.nextLine();
    
    System.out.println("Enter a topping:");
    String topping = input.nextLine();
    
    System.out.println("One" + " " + flavour + ", " + fruit + " " + "sundae topped with" + " " + topping + " " + "coming right up!");
  }
}