import java.util.Scanner;
public class Triangle {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter the height of your triangle in cm:");
    Double height = input.nextDouble();
    
    System.out.println("Enter the base of your triangle in cm:");
    Double base = input.nextDouble();
    
    System.out.println("The area of your triangle in cm^2 is" + " " + base * height / 2 + ".");
  }
}