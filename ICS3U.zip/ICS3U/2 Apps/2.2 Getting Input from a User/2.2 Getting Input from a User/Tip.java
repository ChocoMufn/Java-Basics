import java.util.Scanner;
public class Tip {
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
   
    System.out.println("Enter an restaurant bill:");
    Double bill = input.nextDouble();
    
    System.out.println("A 16% tip is" + " " + bill * 0.16 + " " + "dollars.");
  }
}