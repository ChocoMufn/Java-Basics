import java.util.Scanner; 
public class WinLoseDraw
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("What's team A's score?");
    int a = input.nextInt();
    System.out.println("What's team B's score??");
    int b = input.nextInt();
    
    if (a > b)
    {
        System.out.println(" ");
        System.out.println("Team A wins!!");
    }
    else if (a < b)
    {
        System.out.println(" ");
        System.out.println("Team B wins!!");
    }
    else
    {
        System.out.println(" ");
        System.out.println("It's a Draw");
    }    
    
}
}