import java.util.Scanner; 
public class Coin
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("Flip a coin!");
    System.out.println("I call heads!");
    System.out.println("What side did it land on?: ");
    String face = input.nextLine();
    
    if (face.toLowerCase().equals("heads"))
    {
        System.out.println("I Win! :D");
    }
    else
    {
        System.out.println("You Win. :(");
    }
    
    
}
}