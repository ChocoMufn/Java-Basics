import java.util.Scanner; 
public class Dinner2
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("Welcome to The International Food House!");
    System.out.println("Would you like our meat meal or vegetarian meal?");
    String type = input.nextLine();
    System.out.println("Would you like it fried or baked?");
    String cook = input.nextLine();
    
    if (type.toLowerCase().equals("meat") && cook.toLowerCase().equals("fried"))
    {
        System.out.println(" ");
        System.out.println("I think you would like our hot and sour Fried Chicken Balls!");
    }
    else if (type.toLowerCase().equals("vegetarian") && cook.toLowerCase().equals("fried"))
    {
        System.out.println(" ");
        System.out.println("I think you would like our scrumptious Vegetable Pakoras!");
       
    }
    else if (type.toLowerCase().equals("meat") && cook.toLowerCase().equals("baked"))
    {
        System.out.println(" ");
        System.out.println("I think you would like our creamy Chicken Casserole!");
    }
    else if (type.toLowerCase().equals("vegetarian") && cook.toLowerCase().equals("baked")) 
    {
        System.out.println(" ");
        System.out.println("I think you would like our spicy Black Bean Enchiladas!");
    }
    else
    {
        System.out.println(" ");
        System.out.println("Sorry, we don't seem to have that here.");
    }    
    
}
}