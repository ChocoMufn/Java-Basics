import java.util.Scanner; 
public class Hurricane3
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("What's the wind speed?");
    int speed = input.nextInt();
    
    if (speed <= 118)
    {
        System.out.println(" ");
        System.out.println("Stop panicking...it's just some wind!");
    }
    else if (speed <= 152)
    {
        System.out.println(" ");
        System.out.println("Its a category Category 1.");
    }
    else if (speed <= 177)
    {
        System.out.println(" ");
        System.out.println("Category 2!");
    }
    else if (speed <= 208)
    {
        System.out.println(" ");
        System.out.println("Category 3!!!!");
    }
    else if (speed <= 251)
    {
        System.out.println(" ");
        System.out.println("Category 4!!!! Run!!!");
    }
    else
    {
        System.out.println(" ");
        System.out.println("Category 5!!!! Category 5!!!! Get out of here!!!");
    }    
    
}
}