import java.util.Scanner; 
public class Hurricane2
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
    System.out.println("What's the wind speed?");
    int speed = input.nextInt();
    
    if (speed >= 252)
    {
        System.out.println(" ");
        System.out.println("Category 5!!!! Category 5!!!! Get out of here!!!");
    }
    else if (speed >= 209)
    {
        System.out.println(" ");
        System.out.println("Category 4!!!! Run!!!");
    }
    else if (speed >= 178)
    {
        System.out.println(" ");
        System.out.println("Category 3!!!!");
    }
    else if (speed >= 154)
    {
        System.out.println(" ");
        System.out.println("Category 2!");
    }
    else if (speed >= 119)
    {
        System.out.println(" ");
        System.out.println("Its a category Category 1.");
    }
    else
    {
        System.out.println(" ");
        System.out.println("Stop panicking...it's just some wind!");
    }    
    
}
}