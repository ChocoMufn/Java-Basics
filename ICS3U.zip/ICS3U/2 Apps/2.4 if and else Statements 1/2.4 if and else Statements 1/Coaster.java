import java.util.Scanner; 
public class Coaster
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("Welcome to the Cranium Coaster, what is your height?");
    int height = input.nextInt();
    
    if (height >= 140)
    {
        System.out.println("You may ride!");
    }
    else
    {
        System.out.println("Sorry, try again next year.");
    }
    
    
}
}
