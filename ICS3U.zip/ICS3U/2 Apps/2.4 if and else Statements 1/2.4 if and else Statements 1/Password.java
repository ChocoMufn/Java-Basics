
import java.util.Scanner; 
public class Password
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("Welcome to Fort Knox, what is the password?");
    String pass = input.nextLine();
    
    if (pass == "password")
    {
        System.out.println("Access Granted");
        System.out.println("You have $999999999999 worth in gold");
    }
    else
    {
        System.out.println("Incorrect Password");
        System.out.println("Account has been temporarily locked");
    }
}
}