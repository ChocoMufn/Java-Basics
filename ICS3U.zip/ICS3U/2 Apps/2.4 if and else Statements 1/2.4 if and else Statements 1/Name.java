import java.util.Scanner; 
public class Name
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("Enter your first name");
    String first = input.nextLine();
    
    System.out.println("Enter your last name");
    String last = input.nextLine();
    
    if (first.equals("Bill") && last.equals("Gates"))
    {
        System.out.println("Hello!");
    }
    else
    {
        System.out.println("Nice to meet you!");
    }
}
}