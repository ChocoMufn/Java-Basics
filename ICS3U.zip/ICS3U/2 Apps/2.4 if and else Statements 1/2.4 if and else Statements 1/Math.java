import java.util.Scanner; 
public class Math
{   
    public static void main (String[] args){
    Scanner input = new Scanner(System.in);
        
    System.out.println("What is x if x = (2*5)/2");
    int pass = input.nextInt();
    
    if (pass == 5)
    {
        System.out.println("Correct");
    }
    else
    {
        System.out.println("Incorrect");
    }
}
}