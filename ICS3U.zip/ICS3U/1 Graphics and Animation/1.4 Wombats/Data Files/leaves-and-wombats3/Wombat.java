import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Wombats can move and eat Leafs.
 * 
 * @author S. Camilleri
 */
public class Wombat extends Actor
{
    private int leavesEaten;

    public Wombat()
    {
        leavesEaten = 0;
    }

    /**
     * Do whatever the wombat likes to to just now.
     */
    public void act()
    {
        move(3);
    }

    /**
     * Move one step forward.
     */
    public void move()
    {
        move(1);
    }
    
    /**
     * Turn left by 90 degrees.
     */
    public void turnLeft()
    {
        turn(-90);
    }
    
    /**
     * Eat a leaf (if there is one in our cell).
     */
    public void eatLeaf()
    {
        Actor leaf = getOneObjectAtOffset(0, 0, Leaf.class);
        if (leaf != null) {
            // eat the leaf...
            getWorld().removeObject(leaf);
            leavesEaten = leavesEaten + 1; 
        }
    }
    
    /**
     * Set the direction we're facing. The 'direction' parameter must
     * be in the range [0..8].
     */
    public void setDirection(int direction)
    {
        setRotation(direction * 45);
    }

    /**
     * Tell how many leaves we have eaten.
     */
    public int getLeavesEaten()
    {
        return leavesEaten;
    }
}
