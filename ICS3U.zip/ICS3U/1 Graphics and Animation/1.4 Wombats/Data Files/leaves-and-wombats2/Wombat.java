import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Wombats eat Leafs and keep track of how many.
 * 
 * @author S. Camilleri
 */
public class Wombat extends Actor
{
    private int leavesEaten;
    private int stepsTaken;

    public Wombat()
    {
        leavesEaten = 0;
        stepsTaken = 0;
    }
    

    /**
     * Do whatever the wombat likes to to just now.
     */
    public void act()
    {
        move(3);

    }

    /**
     * Move one step forward.
     */
    public void move()
    {
        move(1);
        stepsTaken = stepsTaken + 1;
    }
    
    /**
     * Turn left by 90 degrees.
     */
    public void turnLeft()
    {
        turn(-90);
    }
       
    
    /**
     * Eat a leaf (if there is one in our cell).
     */
    public void eatLeaf()
    {
        Actor leaf = getOneObjectAtOffset(0, 0, Leaf.class);
        if (leaf != null) {
            // eat the leaf...
            getWorld().removeObject(leaf);
            leavesEaten = leavesEaten + 1; 
        }
    }
    
    /**
     * Tell how many leaves we have eaten.
     */
    public int getLeavesEaten()
    {
        return leavesEaten;
    }
    public int getStepsTaken()
    {
        return stepsTaken;
    }
}
