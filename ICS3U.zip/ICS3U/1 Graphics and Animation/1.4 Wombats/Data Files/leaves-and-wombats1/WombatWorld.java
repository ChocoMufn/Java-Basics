import greenfoot.*;

/**
 * A world where wombats live.
 * @author Michael Kölling @version 2.0
 */
public class WombatWorld extends World
{

    /* imports Actor, World, Greenfoot, GreenfootImage*/

    /**
     * Create a new world with 10x10 cells and with a cell size of 60x60 pixels.
     */
    public WombatWorld()
    {
        super(10, 10, 60);
        setPaintOrder(Wombat.class, Leaf.class);
        /* draw wombat on top of leaf*/
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Wombat wombat =  new  Wombat();
        addObject(wombat, 0, 0);
        Leaf leaf =  new  Leaf();
        addObject(leaf, 5, 5);
        Leaf leaf2 =  new  Leaf();
        addObject(leaf2, 5, 3);
        Leaf leaf3 =  new  Leaf();
        addObject(leaf3, 4, 7);
    }
}
