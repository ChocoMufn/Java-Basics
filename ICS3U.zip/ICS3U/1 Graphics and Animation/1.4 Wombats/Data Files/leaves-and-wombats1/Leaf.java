import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Leaf - a class for representing leaves.
 *
 * @author Michael Kölling
 * @version 2.0
 */
public class Leaf extends Actor
{
    public Leaf()
    {
    }
}
