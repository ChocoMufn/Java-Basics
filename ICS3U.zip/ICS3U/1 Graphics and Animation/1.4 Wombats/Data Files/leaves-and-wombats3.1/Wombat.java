import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Wombats can move and eat Leafs.
 * 
 * @author S. Camilleri
 */
public class Wombat extends Actor
{
    private int leavesEaten;
    private int flanEaten;
    private int pizzaEaten;
    private int chipsEaten;

    public Wombat()
    {
        leavesEaten = 0;
    }

    /**
     * Do whatever the wombat likes to to just now.
     */
    public void act()
    {
        move(1);
        Actor leaf = getOneObjectAtOffset(0, 0, Leaf.class);
        if (leaf != null) {
            // eat the leaf...
            getWorld().removeObject(leaf);
            leavesEaten = leavesEaten + 1; 
    }
    Actor flan = getOneObjectAtOffset(0, 0, Flan.class);
        if (flan != null) {
            // eat the flan...
            getWorld().removeObject(flan);
            flanEaten = flanEaten + 1; 
    }
    Actor pizza = getOneObjectAtOffset(0, 0, Pizza_Cheese.class);
        if (pizza != null) {
            // eat the pizza...
            getWorld().removeObject(pizza);
            pizzaEaten = pizzaEaten + 1; 
    }
    Actor chips = getOneObjectAtOffset(0, 0, Chips.class);
        if (chips != null) {
            // eat the fries...
            getWorld().removeObject(chips);
            chipsEaten = chipsEaten + 1; 
    }
    }
    /**
     * Move one step forward.
     */
    public void move()
    {
        move(1);
    }
    
    /**
     * Turn left by 90 degrees.
     */
    public void turnLeft()
    {
        turn(-90);
    }
    
    
    /**
     * Set the direction we're facing. The 'direction' parameter must
     * be in the range [0..8].
     */
    public void setDirection(int direction)
    {
        setRotation(direction * 45);
    }

    /**
     * Tell how many leaves we have eaten.
     */
    public int getLeavesEaten()
    {
        return leavesEaten;
    }
    public int getFlanEaten()
    {
        return flanEaten;
    }
    public int getPizza_CheeseEaten()
    {
        return pizzaEaten;
    }
    public int getChipsEaten()
    {
        return chipsEaten;
    }
}
