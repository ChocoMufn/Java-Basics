import greenfoot.*;

/**
 * A world where wombats live.
 * @author Michael Kölling @version 2.0
 */
public class WombatWorld extends World
{

    /* imports Actor, World, Greenfoot, GreenfootImage*/

    /**
     * Create a new world with 10x10 cells and with a cell size of 60x60 pixels.
     */
    public WombatWorld()
    {
        super(10, 10, 60);
        setPaintOrder(Wombat.class, Leaf.class);
        /* draw wombat on top of leaf*/
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Wombat wombat =  new  Wombat();
        addObject(wombat, 0, 0);
        Wombat wombat2 =  new  Wombat();
        addObject(wombat2, 9, 9);

        Leaf leaf = new Leaf();
        addObject(leaf, 2, 0);
        Leaf leaf1 = new Leaf();
        addObject(leaf1, 4, 0);
        Leaf leaf2 = new Leaf();
        addObject(leaf2, 6, 0);
        Leaf leaf3 = new Leaf();
        addObject(leaf3, 8, 0);
        Leaf leaf4 = new Leaf();
        addObject(leaf4, 1, 9);
        Leaf leaf5 = new Leaf();
        addObject(leaf5, 3, 9);
        Leaf leaf6 = new Leaf();
        addObject(leaf6, 5, 9);
        Leaf leaf7 = new Leaf();
        addObject(leaf7, 7, 9);
        
        Flan flan = new Flan();
        addObject(flan, 3, 0);
        Flan flan1 = new Flan();
        addObject(flan1, 3, 9);
        Pizza_Cheese pizza = new Pizza_Cheese();
        addObject(pizza, 5, 0);
        Pizza_Cheese pizza1 = new Pizza_Cheese();
        addObject(pizza1, 5, 9);
        Chips chips = new Chips();
        addObject(chips, 7, 0);
        Chips chips1 = new Chips();
        addObject(chips1, 7, 9);
        

        wombat.setDirection(8);
        wombat.setDirection(5);
        wombat.setDirection(8);
        wombat.setLocation(0,0);
        wombat2.setLocation(9,9);
        wombat2.setLocation(0,0);
        wombat.setLocation(9,9);
        wombat.setLocation(8,8);
        leaf4.setLocation(8,9);
        leaf7.setLocation(6,9);
        leaf6.setLocation(4,9);
        leaf5.setLocation(2,9);
        wombat.setLocation(0,9);
    }
}
