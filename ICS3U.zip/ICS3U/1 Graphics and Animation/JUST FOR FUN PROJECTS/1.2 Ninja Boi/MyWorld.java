import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1080, 720, 1); 
        
        
        
        baguette bg = new baguette();
        addObject(bg,100,310);
        
        hungryfrench hf = new hungryfrench();
        addObject(hf,300,310);
        hungryfrench hf1 = new hungryfrench();
        addObject(hf1,300,310);
        hungryfrench hf2 = new hungryfrench();
        addObject(hf2,300,310);
        hungryfrench hf3 = new hungryfrench();
        addObject(hf3,300,310);
        hungryfrench hf4 = new hungryfrench();
        addObject(hf4,300,310);
        
        hungryfrench hf5 = new hungryfrench();
        addObject(hf5,300,310);
        hungryfrench hf6 = new hungryfrench();
        addObject(hf6,300,310);
        hungryfrench hf7 = new hungryfrench();
        addObject(hf7,300,310);
        hungryfrench hf8 = new hungryfrench();
        addObject(hf8,300,310);
        hungryfrench hf9 = new hungryfrench();
        addObject(hf9,300,310);

        hungryfrench hf10 = new hungryfrench();
        addObject(hf10,300,310);
        hungryfrench hf11 = new hungryfrench();
        addObject(hf11,300,310);
        hungryfrench hf12 = new hungryfrench();
        addObject(hf12,300,310);
        hungryfrench hf13 = new hungryfrench();
        addObject(hf13,300,310);
        hungryfrench hf14 = new hungryfrench();
        addObject(hf14,300,310);
        
        hungryfrench hf15 = new hungryfrench();
        addObject(hf15,300,310);
        hungryfrench hf16 = new hungryfrench();
        addObject(hf16,300,310);
        hungryfrench hf17 = new hungryfrench();
        addObject(hf17,300,310);
        hungryfrench hf18 = new hungryfrench();
        addObject(hf18,300,310);
        hungryfrench hf19 = new hungryfrench();
        addObject(hf19,300,310);
    }
}
