import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class baguette here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class baguette extends Actor
{
    /**
     * Act - do whatever the baguette wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(12);
        if (Greenfoot.isKeyDown("a"))
        {
            turn (5);
        }    
        if (Greenfoot.isKeyDown("d"))
        {
            turn (-5);
        }    
    }
}
