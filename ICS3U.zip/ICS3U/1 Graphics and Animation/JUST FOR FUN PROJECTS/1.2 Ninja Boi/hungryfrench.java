import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class hungryfrench here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class hungryfrench extends Actor
{
    /**
     * Act - do whatever the hungryfrench wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(5);
        if ( isAtEdge() )
        {
            turn(randyboy());
            
        }
        if (isTouching(baguette.class))
        {
            removeTouching(baguette.class);
            Greenfoot.setWorld(new MyWorld());
        }

    }    
    public int randyboy()
    {
        int degree = Greenfoot.getRandomNumber(360);
        return degree;
    }
}
