import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Eggs are laid by Chickens.
 * 
 * @author S. Camilleri
 */
public class Egg extends Actor
{
    public void act() 
    {
    }    
}
