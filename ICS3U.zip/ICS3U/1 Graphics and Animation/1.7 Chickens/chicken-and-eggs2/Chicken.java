import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Chickens lay eggs and have names.
 * 
 * @author S. Camilleri
 */
public class Chicken extends Actor
{
    private String name;
    public int Eggs;
   
        
    
    public Chicken()
    {
        Eggs = 0;
        
    }
    
    
    public void act() 
    {
        move(1);
        
        Egg egg = new Egg();
        int x = getX();
        int y = getY();
        getWorld().addObject(egg, x, y + 1);
        
    }
    
    public void setName(String newName)
    {
        name = newName;
    }
    
    public int getEggs()
    {
        return Eggs;
    }
    
    
    
    public void layEgg()
    {
        Egg egg = new Egg();
        int x = getX();
        int y = getY();
        getWorld().addObject(egg, x, y + 1);
        Eggs = Eggs + 1;
    }
}
