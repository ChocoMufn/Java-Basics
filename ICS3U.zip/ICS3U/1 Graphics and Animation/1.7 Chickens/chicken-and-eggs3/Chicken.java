import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Chickens lay eggs and have names.
 * 
 * @author S. Camilleri
 */
public class Chicken extends Actor
{
    private String name;

    public void act() 
    {
        move(1);
        
        if ( isAtEdge() )
        {
            turn(randyboy());
            Egg egg = new Egg();
            getWorld().addObject(egg, getX(), getY());
        }
    }
    
    public void setName(String newName)
    {
        name = newName;
    }
    
    public void layEgg()
    {
        Egg egg = new Egg();
        getWorld().addObject(egg, 0, 0);
    }
    public int randyboy()
    {
        int degree = Greenfoot.getRandomNumber(360);
        return degree;
    }
    
    
}
