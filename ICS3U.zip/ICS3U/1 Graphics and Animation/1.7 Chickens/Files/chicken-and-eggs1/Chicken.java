import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Chicken extends Actor
{
    private String name;
    
    public void act() 
    {
        move(1);
    }
    
    public void fly(int distance)
    {
        move(distance);
    }
    
    public void setName(String newName)
    {
        name = newName;
    }
}
