import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This class represents the lobster.
 * 
 * @author Mr. Camilleri
 */
public class Lobster extends Actor
{
    public int count = 0;
    /**
     * Act - do whatever the Lobster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        while (count < 6){
        uTurn();
        
    }
      
    }
    public void reset()
    {
        setLocation(1,1);
    }
    
    public void uTurn()
    {
        move(1);
        turn(30);
        count += 1;
    }
   
 
}
