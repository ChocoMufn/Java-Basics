import greenfoot.*;

/**
 * This class represents the kitchen.
 * 
 * @author Mr. Camilleri
 */
public class Kitchen extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Kitchen()
    {    
        // Create a new world with 12x8 cells with a cell size of 50x50 pixels.
        super(12, 8, 50); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        // Make a new Lobster object
        Lobster lobster = new Lobster();

        // Place the Lobster at coordinates (1, 6) in MyWorld
        addObject(lobster,5,4);
    }
}
