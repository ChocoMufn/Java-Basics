import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This class represents the lobster.
 * 
 * @author Mr. Camilleri
 */
public class Lobster extends Actor
{
  
    public int count = 0;
    /**
     * Act - do whatever the Lobster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (count == 0){
            turnLeft();
        }
        else{
            turnRight();
        }
    }
    
    public void turnLeft()
    {
        turn(-90);
        move (1);
        count = 1;
    }
    
    public void turnRight()
    {
        turn(90); 
        move (1);
        count = 0;
    }
    
    
}
