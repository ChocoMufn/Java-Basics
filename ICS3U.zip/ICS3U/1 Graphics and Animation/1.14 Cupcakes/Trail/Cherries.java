import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cherries here.
 * 
 * @author S. Camilleri
 */
public class Cherries extends Actor
{
    private int timer;
    /**
     * Act - do whatever the Cherries wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (timer == 0)
        {
            Cherries cherries = new Cherries();
            getWorld().addObject(cherries, randX(), randY());
            timer = 90;
        }
        
        timer -= 1;
    }    
    public int randY()
    {
        int randomY = Greenfoot.getRandomNumber(400);
        return randomY;
    }
    public int randX()
    {
        int randomX = Greenfoot.getRandomNumber(600);
        return randomX;
    }
}
