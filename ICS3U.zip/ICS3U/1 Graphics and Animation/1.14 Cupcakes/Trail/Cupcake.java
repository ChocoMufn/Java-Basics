import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cupcake here.
 * 
 * @author S. Camilleri
 */
public class Cupcake extends Actor
{
    private int timer;
    /**
     * Act - do whatever the Cupcake wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(2);
        
        if (timer == 0)
        {
            Cherries cherries = new Cherries();
            getWorld().addObject(cherries, getX(), getY());
            timer = 50;
        }
        timer -= 1;
    }    
}
