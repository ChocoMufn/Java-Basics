import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Anteater anteater = new Anteater();
        addObject(anteater,100,310);
        
        
       
       

        Ant ant = new Ant();
        addObject(ant,102,305);
        Ant ant2 = new Ant();
        addObject(ant2,139,312);
        Ant ant3 = new Ant();
        addObject(ant3,200,312);
        Ant ant4 = new Ant();
        addObject(ant4,239,322);
        Ant ant5 = new Ant();
        addObject(ant5,280,325);
        Ant ant6 = new Ant();
        addObject(ant6,320,307);
        
  
        
        
   
    }
}
