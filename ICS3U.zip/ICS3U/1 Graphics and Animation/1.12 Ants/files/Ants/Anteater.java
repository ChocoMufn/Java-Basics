import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Anteater here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Anteater extends Actor
{
    /**
     * Act - do whatever the Anteater wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int full = 0;

  
    public void act() 
    {
        move(3);
        
        if (isTouching(Ant.class))
        {
            removeTouching(Ant.class);
            full = full + 1;
        }
        
    }    
    public int getFull()
    {
        return full;
    }   
}
