import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 900, 1); 
        
        Kangaroo kangaroo = new Kangaroo();
        addObject(kangaroo, 100, 100); 
        
        Orange orange1 = new Orange();
        addObject(orange1, 200, 100); 
        Orange orange2 = new Orange();
        addObject(orange2, 300, 100); 
        Orange orange3 = new Orange();
        addObject(orange3, 400, 100); 
        Orange orange4 = new Orange();
        addObject(orange4, 500, 100); 
        Orange orange11 = new Orange();
        addObject(orange1, 200, 100); 
        Orange orange21 = new Orange();
        addObject(orange2, 300, 100); 
        Orange orange31 = new Orange();
        addObject(orange3, 400, 100); 
        Orange orange41 = new Orange();
        addObject(orange41, 500, 100); 
        Orange orange111 = new Orange();
        addObject(orange111, 200, 100); 
        Orange orange211 = new Orange();
        addObject(orange211, 300, 100); 
        Orange orange311 = new Orange();
        addObject(orange311, 400, 100); 
        Orange orange411 = new Orange();
        addObject(orange411, 500, 100); 
        Orange orange1111 = new Orange();
        addObject(orange1111, 200, 100); 
        Orange orange2111 = new Orange();
        addObject(orange2111, 300, 100); 
        Orange orange3111 = new Orange();
        addObject(orange3111, 400, 100); 
        Orange orange4111 = new Orange();
        addObject(orange4111, 500, 100); 
        Orange orange11111 = new Orange();
        addObject(orange11111, 200, 100); 
        Orange orange21111 = new Orange();
        addObject(orange21111, 300, 100); 
        Orange orange31111 = new Orange();
        addObject(orange31111, 400, 100); 
        Orange orange41111 = new Orange();
        addObject(orange4111, 500, 100); 
        Orange orange12 = new Orange();
        addObject(orange12, 200, 100); 
        Orange orange22 = new Orange();
        addObject(orange22, 300, 100); 
        Orange orange32 = new Orange();
        addObject(orange32, 400, 100); 
        Orange orange42 = new Orange();
        addObject(orange42, 500, 100); 
        
        Orange orange19 = new Orange();
        addObject(orange19, 200, 100); 
        Orange orange29 = new Orange();
        addObject(orange29, 300, 100); 
        Orange orange39 = new Orange();
        addObject(orange39, 400, 100); 
        Orange orange49 = new Orange();
        addObject(orange49, 500, 100); 
        Orange orange191 = new Orange();
        addObject(orange191, 200, 100); 
        Orange orange219 = new Orange();
        addObject(orange219, 300, 100); 
        Orange orange319 = new Orange();
        addObject(orange319, 400, 100); 
        Orange orange419 = new Orange();
        addObject(orange419, 500, 100); 
        Orange orange1119 = new Orange();
        addObject(orange1119, 200, 100); 
        Orange orange2119 = new Orange();
        addObject(orange2119, 300, 100); 
        Orange orange3119 = new Orange();
        addObject(orange3119, 400, 100); 
        Orange orange4119 = new Orange();
        addObject(orange4119, 500, 100); 
        Orange orange11119 = new Orange();
        addObject(orange11119, 200, 100); 
        Orange orange21119 = new Orange();
        addObject(orange21119, 300, 100); 
        Orange orange31119 = new Orange();
        addObject(orange31119, 400, 100); 
        Orange orange41119 = new Orange();
        addObject(orange41119, 500, 100); 
        Orange orange111119 = new Orange();
        addObject(orange111119, 200, 100); 
        Orange orange211119 = new Orange();
        addObject(orange211119, 300, 100); 
        Orange orange311119 = new Orange();
        addObject(orange311119, 400, 100); 
        Orange orange411119 = new Orange();
        addObject(orange411119, 500, 100); 
        Orange orange129 = new Orange();
        addObject(orange129, 200, 100); 
        Orange orange229 = new Orange();
        addObject(orange229, 300, 100); 
        Orange orange329 = new Orange();
        addObject(orange329, 400, 100); 
        Orange orange429 = new Orange();
        addObject(orange429, 500, 100); 
        
        Orange orange198 = new Orange();
        addObject(orange198, 200, 100); 
        Orange orange298 = new Orange();
        addObject(orange298, 300, 100); 
        Orange orange398 = new Orange();
        addObject(orange398, 400, 100); 
        Orange orange498 = new Orange();
        addObject(orange498, 500, 100); 
        Orange orange1918 = new Orange();
        addObject(orange1918, 200, 100); 
        Orange orange2198 = new Orange();
        addObject(orange2198, 300, 100); 
        Orange orange3198 = new Orange();
        addObject(orange3198, 400, 100); 
        Orange orange4198 = new Orange();
        addObject(orange4198, 500, 100); 
        Orange orange11198 = new Orange();
        addObject(orange11198, 200, 100); 
        Orange orange21198 = new Orange();
        addObject(orange21198, 300, 100); 
        Orange orange31198 = new Orange();
        addObject(orange31198, 400, 100); 
        Orange orange41198 = new Orange();
        addObject(orange41198, 500, 100); 
        Orange orange111198 = new Orange();
        addObject(orange111198, 200, 100); 
        Orange orange211198 = new Orange();
        addObject(orange211198, 300, 100); 
        Orange orange311198 = new Orange();
        addObject(orange311198, 400, 100); 
        Orange orange411198 = new Orange();
        addObject(orange411198, 500, 100); 
        Orange orange1111198 = new Orange();
        addObject(orange1111198, 200, 100); 
        Orange orange2111198 = new Orange();
        addObject(orange2111198, 300, 100); 
        Orange orange3111198 = new Orange();
        addObject(orange3111198, 400, 100); 
        Orange orange4111198 = new Orange();
        addObject(orange4111198, 500, 100); 
        Orange orange1298 = new Orange();
        addObject(orange1298, 200, 100); 
        Orange orange2298 = new Orange();
        addObject(orange2298, 300, 100); 
        Orange orange3298 = new Orange();
        addObject(orange3298, 400, 100); 
        Orange orange4298 = new Orange();
        addObject(orange4298, 500, 100); 
        
        Orange orange1980 = new Orange();
        addObject(orange1980, 200, 100); 
        Orange orange2980 = new Orange();
        addObject(orange2980, 300, 100); 
        Orange orange3980 = new Orange();
        addObject(orange3980, 400, 100); 
        Orange orange4980 = new Orange();
        addObject(orange4980, 500, 100); 
        Orange orange19180 = new Orange();
        addObject(orange19180, 200, 100); 
        Orange orange21980 = new Orange();
        addObject(orange21980, 300, 100); 
        Orange orange31980 = new Orange();
        addObject(orange31980, 400, 100); 
        Orange orange41980 = new Orange();
        addObject(orange41980, 500, 100); 
        Orange orange111980 = new Orange();
        addObject(orange111980, 200, 100); 
        Orange orange211980 = new Orange();
        addObject(orange211980, 300, 100); 
        Orange orange311980 = new Orange();
        addObject(orange311980, 400, 100); 
        Orange orange411980 = new Orange();
        addObject(orange411980, 500, 100); 
        Orange orange1111980 = new Orange();
        addObject(orange1111980, 200, 100); 
        Orange orange2111980 = new Orange();
        addObject(orange2111980, 300, 100); 
        Orange orange3111980 = new Orange();
        addObject(orange3111980, 400, 100); 
        Orange orange4111980 = new Orange();
        addObject(orange4111980, 500, 100); 
        Orange orange11111980 = new Orange();
        addObject(orange11111980, 200, 100); 
        Orange orange21111980 = new Orange();
        addObject(orange21111980, 300, 100); 
        Orange orange31111980 = new Orange();
        addObject(orange31111980, 400, 100); 
        Orange orange41111980 = new Orange();
        addObject(orange41111980, 500, 100); 
        Orange orange12980 = new Orange();
        addObject(orange12980, 200, 100); 
        Orange orange22980 = new Orange();
        addObject(orange22980, 300, 100); 
        Orange orange32980 = new Orange();
        addObject(orange32980, 400, 100); 
        Orange orange42980 = new Orange();
        addObject(orange42980, 500, 100); 
    }
}
