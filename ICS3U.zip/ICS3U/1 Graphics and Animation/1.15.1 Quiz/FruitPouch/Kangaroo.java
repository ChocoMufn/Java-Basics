import greenfoot.*;

/**
 * Kangaroos can pick up Oranges and put them in their pouch, as well as put them back down.
 * 
 * @author S. Camilleri
 */
public class Kangaroo extends Actor
{
    private int fruitInPouch;
    public void act() 
    {
        
        if (Greenfoot.isKeyDown("a"))
        {
            turn (5);
            move (10);
        }    
        if (Greenfoot.isKeyDown("d"))
        {
            turn (-5);
            move (10);
        }    
        if (Greenfoot.isKeyDown("1"))
        {
            if (isTouching(Orange.class))
            {
                removeTouching(Orange.class);
                fruitInPouch += 1;
            }
        }  
        if (Greenfoot.isKeyDown("2"))
        {
            if (fruitInPouch == 0)
            {
            Orange orange = new Orange();
            getWorld().addObject(orange, getX(), getY());
            fruitInPouch = 0 ;
            }
     
        }  
    }
   
    
    public void pickUp()
    {
        if (isTouching(Orange.class))
        {
            removeTouching(Orange.class);
            fruitInPouch += 1;
        }
    }
    
    public void putDown()
    {
        if (fruitInPouch > 0)
        {
            Orange orange = new Orange();
            getWorld().addObject(orange, getX(), getY());
            fruitInPouch -= 1;
        }
    }
    public int getSupply()
    {
        return  fruitInPouch;
    }
}
